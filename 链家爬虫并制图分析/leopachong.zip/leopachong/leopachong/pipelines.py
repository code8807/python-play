# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import csv
from leopachong.items import Constant
class LeopachongPipeline(object):
    def __init__(self):
        with open('d://%s.csv' %(Constant().district), 'a+', encoding='utf-8', newline='') as csvfile:
            fieldnames = ['单元名称', '单元类型', '单元地区', '价格','单位']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
    def process_item(self, item, spider):
        with open('d://%s.csv' %(Constant().district), 'a+', encoding='utf-8', newline='') as csvfile:
            fieldnames = ['单元名称', '单元类型', '单元地区', '价格','单位']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writerow(
                {'单元名称': item['name'], '单元类型': item['type'], '单元地区': item['area'], '价格': item['price'],'单位':item['unit']})
