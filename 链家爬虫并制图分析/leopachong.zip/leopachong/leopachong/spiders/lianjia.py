# -*- coding: utf-8 -*-
import scrapy
from leopachong.items import LeopachongItem,Constant

class LianjiaSpider(scrapy.Spider):
    name = 'lianjia'
    allowed_domains = ['m.lianjia.com']
    start_urls = ['https://m.lianjia.com/sh/loupan/%s/' %(Constant().district)]
    offset = 1
    page = 0
    def parse(self, response):
        rooms = response.xpath("//li[@class='resblock-list-item']")
        if (self.offset ==1):
            self.page = response.xpath("//section[@class='toast-inline animation inactive']/span/text()").extract_first()
        for room in rooms:
            item = LeopachongItem()
            item['name'] =  room.xpath(".//div[@class='resblock-name-line']/h3/text()").extract_first()
            item['type'] = room.xpath(".//div[@class='resblock-name-line']/span[1]/text()").extract_first()
            item['area'] = room.xpath(".//div[@class='resblock-location-line']/text()").extract_first()
            item['price'] = room.xpath(".//div[@class='resblock-price']/span[@class='price_num']/text()").extract_first()
            item['unit'] = room.xpath(".//div[@class='resblock-price']/span[@class='price_bunch']/text()").extract_first()
            yield item
        if self.offset < int(self.page)/20:
            self.offset += 1
        yield scrapy.Request(self.start_urls[0] + 'pg' + str(self.offset), callback = self.parse )